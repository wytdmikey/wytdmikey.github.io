# mikey's fun house Repo

i archive old shit or anything else i feel like archiving for my kodi setup yesyes

## Installation

See https://wytdmikey.github.io for installation instructions.
